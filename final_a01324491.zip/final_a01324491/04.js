use airbnbmex

db.listings.find({
	location: { $geoWithin: {$centerSphere: [[-99.17167,19.425],2/6378.1]}},
	accommodates: {$gte: 4},
	minimum_nights: {$lte: 2},
	maximum_nights: {$gte: 2},
	amenities: "Pets allowed",
})
