use airbnbmex

db.listings.createIndex({"location": "2dsphere"})

db.listings.find({
	property_type: "Apartment",
	accommodates: {$gte: 6},
	location: {
		$near: {
			$geometry: {type: "Point", coordinates: [-99.1433887, 19.4352]},
			$maxDistance: 2000
		}
	},
	minimum_nights: 1
}).limit(10)
