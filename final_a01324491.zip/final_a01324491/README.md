# README

Los archivos conteniendo las respuestas a su respectivo ejercicio son:

* 01.txt
* 02.js
* 03.js
* 04.js

Los archivos con terminación "js" están diseñados para ser pasados
a la shell de mongo después de la base de datos ser importada. E.g.:

```
mongo < 02.js
```
