use airbnbmex

db.listings.find( {
	property_type: "Apartment",
	accommodates: { $gte: 2 }
})
